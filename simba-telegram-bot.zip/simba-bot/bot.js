require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');

const TOKEN = process.env.BOT_TOKEN;
const ADMIN_CHAT_ID = process.env.ADMIN_CHAT_ID;

if (!TOKEN) {
  console.error('ERROR: Missing BOT_TOKEN. Copy .env.example to .env and fill in your bot token.');
  process.exit(1);
}

const bot = new TelegramBot(TOKEN, { polling: true });

// ---------- DATA STORAGE ----------
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

const FILES = {
  leads: path.join(DATA_DIR, 'leads.json'),
  candidates: path.join(DATA_DIR, 'candidates.json'),
  replacements: path.join(DATA_DIR, 'replacements.json'),
};

function loadData(file) {
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function saveRecord(file, record) {
  const data = loadData(file);
  record.id = data.length + 1;
  record.timestamp = new Date().toISOString();
  data.push(record);
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
  return record;
}

function toCSV(data) {
  if (data.length === 0) return '';
  const headers = Object.keys(data[0]);
  const rows = data.map((row) =>
    headers.map((h) => `"${(row[h] ?? '').toString().replace(/"/g, '""')}"`).join(',')
  );
  return [headers.join(','), ...rows].join('\n');
}

// ---------- SESSION STATE (in-memory, per chat) ----------
const sessions = {};
function resetSession(chatId) {
  sessions[chatId] = { step: null, data: {} };
}

// ---------- MENUS ----------
const mainMenu = {
  reply_markup: {
    keyboard: [
      ['📋 Our Services', '👤 Apply as Staff'],
      ['🔄 Request Replacement Staff', 'ℹ️ About Us'],
      ['📞 Contact'],
    ],
    resize_keyboard: true,
  },
};

// ---------- START ----------
bot.onText(/\/start/, (msg) => {
  resetSession(msg.chat.id);
  bot.sendMessage(
    msg.chat.id,
    `Welcome to Simba Business Group PLC 👋\n\n` +
      `We help hotels, restaurants, and supermarkets with consulting, staffing, and supply.\n\n` +
      `How can we help you today?`,
    mainMenu
  );
});

// ---------- MAIN MESSAGE HANDLER ----------
bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const text = (msg.text || '').trim();

  if (text === '/start' || text.startsWith('/stats') || text.startsWith('/findcandidates') || text.startsWith('/export')) {
    return; // handled by dedicated handlers below
  }

  if (!sessions[chatId]) resetSession(chatId);
  const session = sessions[chatId];

  // ----- Main menu routing (only when not mid-flow) -----
  if (!session.step) {
    switch (text) {
      case '📋 Our Services':
        return showServices(chatId);
      case '👤 Apply as Staff':
        session.step = 'apply_name';
        session.data = { type: 'candidate' };
        return bot.sendMessage(chatId, "Great! Let's get your application started.\n\nWhat's your full name?");
      case '🔄 Request Replacement Staff':
        session.step = 'replace_business';
        session.data = { type: 'replacement' };
        return bot.sendMessage(chatId, "Let's log your staffing request.\n\nWhat's your business name?");
      case 'ℹ️ About Us':
        return bot.sendMessage(
          chatId,
          'Simba Business Group PLC — 10+ years of hospitality operations experience, ' +
            'ISO 9001:2015 certified, Stanford Seed alumnus.\n\n' +
            'We offer:\n• Hospitality Consulting\n• Trained Staffing Placement\n• Product Supply\n\n' +
            'Type /start to see the menu again.'
        );
      case '📞 Contact':
        return bot.sendMessage(chatId, '📞 [Phone Number]\n✉️ [Email Address]\n🌐 [Website]');
      default:
        return bot.sendMessage(chatId, 'Please choose an option from the menu below, or type /start.', mainMenu);
    }
  }

  // ----- Multi-step flow routing -----
  handleFlow(chatId, session, text, msg);
});

function showServices(chatId) {
  bot.sendMessage(
    chatId,
    `*Our Service Tiers*\n\n` +
      `*Tier 1 — Diagnostic Audit*\nA 3–5 day operational review with a written action plan.\n\n` +
      `*Tier 2 — Full Launch / Turnaround Support*\n4–12 weeks of hands-on setup, SOPs, staffing & training.\n\n` +
      `*Tier 3 — Retainer Advisory*\nOngoing monthly advisory support.\n\n` +
      `Interested in one of these? Reply with 1, 2, or 3, or type "not sure".`,
    { parse_mode: 'Markdown' }
  );
  sessions[chatId].step = 'service_choice';
  sessions[chatId].data = { type: 'lead' };
}

function handleFlow(chatId, session, text, msg) {
  const step = session.step;
  const data = session.data;

  switch (step) {
    // ---------------- LEAD FLOW ----------------
    case 'service_choice':
      data.tier_interest = text;
      session.step = 'lead_business_name';
      return bot.sendMessage(chatId, "What's your business name?");

    case 'lead_business_name':
      data.business_name = text;
      session.step = 'lead_business_type';
      return bot.sendMessage(chatId, 'What type of business? (Hotel / Restaurant / Supermarket / Other)');

    case 'lead_business_type':
      data.business_type = text;
      session.step = 'lead_phone';
      return bot.sendMessage(chatId, 'Best phone number to reach you?');

    case 'lead_phone':
      data.phone = text;
      data.telegram_username = msg.from.username || '';
      finalizeRecord(
        chatId,
        FILES.leads,
        data,
        `✅ Thanks! Your request has been received.\n\nWe'll contact you within 2 business days to schedule a consultation.`,
        `🟢 *New Service Lead*\nBusiness: ${data.business_name}\nType: ${data.business_type}\n` +
          `Interested in: ${data.tier_interest}\nPhone: ${data.phone}\nTelegram: @${data.telegram_username}`
      );
      return;

    // ---------------- CANDIDATE APPLICATION FLOW ----------------
    case 'apply_name':
      data.full_name = text;
      session.step = 'apply_phone';
      return bot.sendMessage(chatId, 'Phone number?');

    case 'apply_phone':
      data.phone = text;
      session.step = 'apply_role';
      return bot.sendMessage(chatId, 'What role are you applying for? (e.g. Waiter, Chef, Housekeeping, Manager, Other)');

    case 'apply_role':
      data.role = text;
      session.step = 'apply_experience';
      return bot.sendMessage(chatId, 'How many years of experience do you have in this role?');

    case 'apply_experience':
      data.experience_years = text;
      session.step = 'apply_city';
      return bot.sendMessage(chatId, 'Which city are you based in?');

    case 'apply_city':
      data.city = text;
      data.telegram_username = msg.from.username || '';
      finalizeRecord(
        chatId,
        FILES.candidates,
        data,
        `✅ Thanks ${data.full_name}! Your application has been received. We'll reach out if there's a matching opportunity.`,
        `👤 *New Candidate Application*\nName: ${data.full_name}\nRole: ${data.role}\n` +
          `Experience: ${data.experience_years} yrs\nCity: ${data.city}\nPhone: ${data.phone}\nTelegram: @${data.telegram_username}`
      );
      return;

    // ---------------- REPLACEMENT REQUEST FLOW ----------------
    case 'replace_business':
      data.business_name = text;
      session.step = 'replace_role';
      return bot.sendMessage(chatId, 'What role do you need to fill? (e.g. Chef, Waiter, Cashier)');

    case 'replace_role':
      data.role_needed = text;
      session.step = 'replace_urgency';
      return bot.sendMessage(chatId, 'How urgent is this? (Immediate / Within a week / Within a month)');

    case 'replace_urgency':
      data.urgency = text;
      session.step = 'replace_contact';
      return bot.sendMessage(chatId, 'Best phone number to reach you?');

    case 'replace_contact':
      data.phone = text;
      data.telegram_username = msg.from.username || '';
      finalizeRecord(
        chatId,
        FILES.replacements,
        data,
        `✅ Got it! Your replacement request has been logged. We'll be in touch shortly with candidate options.`,
        `🔄 *New Replacement Request*\nBusiness: ${data.business_name}\nRole Needed: ${data.role_needed}\n` +
          `Urgency: ${data.urgency}\nPhone: ${data.phone}\nTelegram: @${data.telegram_username}`
      );
      return;

    default:
      resetSession(chatId);
      return bot.sendMessage(chatId, "Let's start over. Type /start.");
  }
}

function finalizeRecord(chatId, file, data, userMessage, adminMessage) {
  saveRecord(file, data);
  bot.sendMessage(chatId, userMessage, mainMenu);
  if (ADMIN_CHAT_ID) {
    bot.sendMessage(ADMIN_CHAT_ID, adminMessage, { parse_mode: 'Markdown' });
  }
  resetSession(chatId);
}

// ---------- ADMIN COMMANDS (only work from your own chat) ----------
bot.onText(/\/stats/, (msg) => {
  if (String(msg.chat.id) !== String(ADMIN_CHAT_ID)) return;
  const leads = loadData(FILES.leads).length;
  const candidates = loadData(FILES.candidates).length;
  const replacements = loadData(FILES.replacements).length;
  bot.sendMessage(
    msg.chat.id,
    `📊 *Stats*\nLeads: ${leads}\nCandidates: ${candidates}\nReplacement Requests: ${replacements}`,
    { parse_mode: 'Markdown' }
  );
});

bot.onText(/\/findcandidates (.+)/, (msg, match) => {
  if (String(msg.chat.id) !== String(ADMIN_CHAT_ID)) return;
  const keyword = match[1].toLowerCase();
  const candidates = loadData(FILES.candidates);
  const matches = candidates.filter((c) => (c.role || '').toLowerCase().includes(keyword));
  if (matches.length === 0) {
    return bot.sendMessage(msg.chat.id, `No candidates found matching "${keyword}".`);
  }
  const list = matches
    .map((c) => `• ${c.full_name} — ${c.role}, ${c.experience_years} yrs, ${c.city}, ${c.phone}`)
    .join('\n');
  bot.sendMessage(msg.chat.id, `🔎 Candidates matching "${keyword}":\n\n${list}`);
});

bot.onText(/\/export/, (msg) => {
  if (String(msg.chat.id) !== String(ADMIN_CHAT_ID)) return;
  let sentAny = false;
  ['leads', 'candidates', 'replacements'].forEach((key) => {
    const data = loadData(FILES[key]);
    if (data.length === 0) return;
    const csv = toCSV(data);
    const filePath = path.join(DATA_DIR, `${key}.csv`);
    fs.writeFileSync(filePath, csv);
    bot.sendDocument(msg.chat.id, filePath);
    sentAny = true;
  });
  if (!sentAny) bot.sendMessage(msg.chat.id, 'No data to export yet.');
});

console.log('Simba Business Group bot is running...');
