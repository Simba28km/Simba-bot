# Simba Business Group — Telegram Bot

A single Telegram bot that handles three things for your business:

1. **Service inquiries** — presents your 3 consulting tiers and captures leads
2. **Staff applications** — candidates apply directly through the chat
3. **Replacement staff requests** — existing clients request a replacement worker

Every time someone completes a flow, **you get an instant Telegram message** with their details. All data is also saved so nothing is lost.

---

## Step 1 — Create your bot (5 minutes)

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Choose a name (e.g. "Simba Business Group") and a username ending in `bot` (e.g. `SimbaBusinessGroupBot`)
4. BotFather will give you a **token** that looks like `123456789:ABCdefGhIJKlmNoPQRstuVwxyz`
5. Copy it — you'll need it in Step 3

## Step 2 — Get your personal Chat ID

This is where lead/candidate/replacement notifications will be sent.

1. Search for **@userinfobot** on Telegram
2. Send it any message
3. It replies with your numeric Chat ID (e.g. `123456789`)
4. Copy it

## Step 3 — Configure the bot

1. Rename `.env.example` to `.env`
2. Open it and fill in:
   ```
   BOT_TOKEN=the_token_from_botfather
   ADMIN_CHAT_ID=your_chat_id_from_userinfobot
   ```

## Step 4 — Install and run

You need [Node.js](https://nodejs.org) installed (version 18 or higher).

```bash
cd simba-bot
npm install
npm start
```

If it worked, you'll see: `Simba Business Group bot is running...`

Open Telegram, search for your bot's username, and send `/start` to test it.

**Important:** this needs to keep running to keep working. If you close the terminal, the bot goes offline. For real use, deploy it to a free always-on host (see Step 5).

---

## Step 5 — Deploy so it runs 24/7

The easiest free option is **Railway** or **Render**:

### Railway (recommended, easiest)
1. Create a free account at [railway.app](https://railway.app)
2. Click "New Project" → "Deploy from GitHub repo" (or "Empty Project" and upload these files)
3. Add your `BOT_TOKEN` and `ADMIN_CHAT_ID` under the project's "Variables" tab
4. Railway will run `npm install` and `npm start` automatically
5. Your bot is now online 24/7

### Render
1. Create a free account at [render.com](https://render.com)
2. Create a new "Background Worker" (not a web service — this bot doesn't need a public URL)
3. Connect your code, set the start command to `npm start`
4. Add `BOT_TOKEN` and `ADMIN_CHAT_ID` as environment variables

---

## Using the bot day-to-day

**As a customer/candidate**, people just message your bot and tap the menu buttons — no technical knowledge needed.

**As the admin (you)**, message your own bot with:

- `/stats` — quick counts of leads, candidates, and replacement requests
- `/findcandidates chef` — searches all applicants for a role (try "waiter", "manager", etc.)
- `/export` — sends you CSV files of everything, ready to open in Excel or import into your Simba_Business_Tracker workbook

All data is also saved permanently in the `data/` folder as JSON files, even if you never run `/export`.

---

## Promoting the bot

Once it's live, share your bot's link (`t.me/YourBotUsername`) on:
- Your Facebook Page
- Instagram/TikTok bio link
- Business cards, WhatsApp status, email signature

Every inquiry that comes in through it lands directly in your Telegram — no missed leads.

---

## Next steps (optional upgrades)

- **Amharic version**: duplicate the menu text and flows in Amharic, or detect language and offer both
- **Facebook Messenger version**: same conversation logic can be rebuilt on Meta's Messenger Platform once you have a Facebook App set up
- **Google Sheets sync**: instead of just CSV export, data can be written live to a Google Sheet so it updates in real time
